(function( $ ) {
    "use strict";

    // on document ready
    $(function(){
        $(".aux-welcome").AuxWizard();
    });
    
})( jQuery );
